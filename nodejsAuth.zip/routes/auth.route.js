const router = require('express').Router();
const authController = require('../controllers/auth.controller')

router.get('/all', (req, res) => {
    authController.getAllUsers(req, res);
}).get('/getuser', (req, res) => {
    authController.getUserDetails(req, res);
}).post('/register', (req, res) => {
    authController.registerUser(req, res);
}).post('/login', (req, res) => {
    authController.login(req, res);
}).delete('/', (req, res) => {
    authController.deleteAll(req, res);
})

module.exports = router
