const jwt = require('jsonwebtoken');
// var privateKey = fs.readFileSync('private.key');
const usersModel = require('../models/auth.model');
const privateKey = process.env.PRIVATE_KEY;

const registerUser = (req, res) => {
    const {email, password, confrimPassword} = req.body;

    if (confrimPassword === password) {
        let user = new usersModel({
            email: email,
            password: password
        })
        user.save(async (err) => {
            if (err) return res.json({error: err})
            else {
                const token = await jwt.sign({id: user._id}, process.env.PRIVATE_KEY);
                return res.json({success: token})
            }
        })
    } else {
        return res.json({error: 'password problem'})
    }


    // jwt.sign({
    //     exp: Math.floor(Date.now() / 1000) + (60 * 60),
    //     data: 'foobar'
    // }, 'secret');


}

const login = (req, res) => {
    const {email, password} = req.body;

    usersModel.findOne({email: email}).then((user) => {
        if (!user) return res.send({error: 'password wrong'});
        if (user.password === password) {
            return res.send({success: 'success'});
        } else {
            return res.send({error: 'password wrong'});
        }

    })
}

const getAllUsers = (req, res) => {
    usersModel.find({}).then((users) => {
        res.send(users)
    })
}

const deleteAll = (req, res) => {
    usersModel.deleteMany({}, (err) => {
        if (err) return res.send({error: err});
        else return res.send({success: 'delete all!'});
    });

}

const getUserDetails = (req, res) => {
    const {authtoken} = req.headers;
    jwt.verify(authtoken, process.env.PRIVATE_KEY, (err, decoded) => {
        if(err) return res.json({error : err});
       return res.json({success : decoded})
    });

}


module.exports = {
    registerUser,
    deleteAll,
    getAllUsers,
    login,
    getUserDetails
}
