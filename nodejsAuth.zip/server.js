const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const app = express();
const authRoute = require('./routes/auth.route');
require('dotenv').config()

app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json());
app.use(cors());

app.use('/api/auth/',authRoute)

mongoose.connect('mongodb://localhost/store', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify: false,
    useCreateIndex: true
}, (err) => {
    if (err) console.log('db error')
    else console.log('db success')
});

app.get('/', (req, res) => {
    return res.json({asfasf: "afasf"})
})

app.listen(8000, () => {
    console.log(`app start at port ${8000}`)
})
